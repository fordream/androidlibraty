/** Automatically generated file. DO NOT MODIFY */
package com.survivingwithandroid.listview.SimpleList;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}