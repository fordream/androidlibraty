/** Automatically generated file. DO NOT MODIFY */
package com.survivingwithandroid.listview_sectionindexer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}