/** Automatically generated file. DO NOT MODIFY */
package com.survivingwithandroid.jsontutorial;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}