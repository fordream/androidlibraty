/** Automatically generated file. DO NOT MODIFY */
package com.survivingwithandroid.listviewdeleteitem;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}